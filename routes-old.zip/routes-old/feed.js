const express = require('express')
const { body } = require('express-validator/check')

const feedController = require('../backend/controllers/feed')
const isAuth = require('../backend/middleware/is-Auth')

const router = express.Router()

// GET /feed/posts
router.get('/posts', isAuth, feedController.getPosts)

router.put('/userStatus', isAuth, feedController.putUserStatus)

// POST /feed/post
router.post(
    '/post',
    isAuth,
    [
        body('title').trim().isLength({ min: 5 }),
        body('content').trim().isLength({ min: 5 }),
    ],
    feedController.createPost
)

router.put(
    '/post/:postId',
    isAuth,
    [
        body('title').trim().isLength({ min: 5 }),
        body('content').trim().isLength({ min: 5 }),
    ],
    feedController.editPost
)

router.delete('/post/:postId', isAuth, feedController.deletePost)

router.get('/post/:postId', isAuth, feedController.getPost)

module.exports = router
